## OperatingSystem specification v. 0.0.1 

**Profile** 

Thing

**Openschemas specification to describe an operating system** 

# Description 
This Virtualization profile specification presents a an abstract representation of virtualization used in a computational environment. 
# Links 
- [Specification](https://openschemas.github.io/specifications/OperatingSystem/)
- [Specification source](OperatingSystem.html)
- [Coding Examples](https://github.com/openschemas/specifications/tree/master/OperatingSystem/tree/master/examples)
- [GitHUb Issues](https://github.com/openschemas/specifications/labels/type%3A%20OperatingSystem)
> These files were generated using [map2model](https://github.com/openschemas/map2model) Python Module.